<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableBooking extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Booking', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('book_id',10);
            $table->dateTime('checkIn_Time');
            $table->dateTime('checkOut_Time');
            $table->bigInteger('cus_id')->unsigned();
            $table->foreign('cus_id')->references('id')->on('Customer');
            $table->bigInteger('emp_id')->unsigned();
            $table->foreign('emp_id')->references('id')->on('Employee');
            $table->bigInteger('room_no')->unsigned();
            $table->foreign('room_no')->references('id')->on('Room');
            $table->bigInteger('pay_id')->unsigned();
            $table->foreign('pay_id')->references('id')->on('Payment');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Booking');
    }
}
