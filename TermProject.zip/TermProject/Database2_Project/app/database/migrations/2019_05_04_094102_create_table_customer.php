<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableCustomer extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Customer', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('cus_id',10);
            $table->string('first_name',45);
            $table->string('last_name',45);
            $table->string('email',100);
            $table->mediumtext('address')->nullable();
            $table->string('phone_no',10);
            $table->integer('num_of_guest');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Customer');
    }
}
