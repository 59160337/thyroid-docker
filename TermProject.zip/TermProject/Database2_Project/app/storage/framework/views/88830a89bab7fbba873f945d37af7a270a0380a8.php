<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div>
                        <a href="<?php echo e(route('customer.createcustomer')); ?>" class="btn btn-success">เพิ่มลูกค้า</a>
                    </div>
                    <div class="panel-heading">
                        <table class="table">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Cus_ID</th>
                                    <th scope="col">first_name</th>
                                    <th scope="col">last_name</th>
                                    <th scope="col">e-mail</th>
                                    <th scope="col">phone_no</th>
                                    <th scope="col">num_of_guest</th>
                                </tr>
                            </thead>
                            {{-- <?php $i=1; ?>
                            <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> --}}
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/customer/index.blade.php */ ?>