<?php $__env->startSection('title','Booking'); ?>

<?php $__env->startSection('content'); ?>
<style>

        th {
            font-size: 100%
        }
        td{
            font-size: 100%
        }
        .example_b {
color: #fff !important;
text-transform: uppercase;
background: #60a3bc;
padding: 20px;
border-radius: 50px;
display: inline-block;
border: none;
}

.example_b:hover {
text-shadow: 0px 0px 6px rgba(255, 255, 255, 1);
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.4s ease 0s;
}
    </style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div>
                        <p><div class="button_cont"><a class="example_b" href="<?php echo e(route('booking.create')); ?>" target="_blank" rel="nofollow noopener">เพิ่มข้อมูลการจอง</a></div></p>
                </div>

                <div class="panel-heading">
                <table class="table">
                    <thead>

                        <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Book ID</th>
                        <th scope="col">checkIn_Time</th>
                        <th scope="col">checkOut_Time</th>
                        <th scope="col">customer ID</th>
                        <th scope="col">employee ID</th>
                        <th scope="col">room ID</th>
                        <th scope="col">pay ID</th>
                        <th scope="col" colspan=2>Operation</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td><?php echo e($row->book_id); ?></td>
                        <td><?php echo e($row->checkIn_Time); ?></td>
                        <td><?php echo e($row->checkOut_Time); ?></td>
                        <td><?php echo e($row->Name); ?></td>
                        <td><?php echo e($row->emp_name); ?></td>
                        <td><?php echo e($row->room_no); ?></td>
                        <td><?php echo e($row->status); ?></td>
                        
                        <td><form action="<?php echo e(route('booking.destroy',$row->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button class="btn btn-danger" type=submit>Delete</button>
                            </form>
                        </tr>

                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/booking/indexbooking.blade.php */ ?>