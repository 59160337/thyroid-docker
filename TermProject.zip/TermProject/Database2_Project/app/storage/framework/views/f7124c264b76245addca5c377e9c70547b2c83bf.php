<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

    

    <?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                    <form method="POST" action="<?php echo e(route('account.store')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <table class="table">
                            <tr>
                                <td><label for="ACC_NO">หมายเลขบัญชี</label></td>
                                <td><input type="text" name="ACC_NO"> </td>
                            </tr>
                            <tr><td><label for="ACC_Name">ชื่อ</label></td>
                                <td><input type="text" name="ACC_Name"> </td>
                            </tr>
                            <tr>
                                <td><label for="ACC_surname">นามสกุล</label></td>
                                <td><input type="text" name="ACC_surname"> </td>
                            </tr>
                            <tr>
                                <td><label for="Balance">จำนวนเงิน</label></td>
                                <td><input type="text" name="Balance"> </td>
                            </tr>
                            <td colspan="2" align="center">
                                    <button class="btn btn-success" type="submit">เปิดบัญชี</button>
                                </td>
                        </table>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>


</body>
</html>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/index.blade.php */ ?>