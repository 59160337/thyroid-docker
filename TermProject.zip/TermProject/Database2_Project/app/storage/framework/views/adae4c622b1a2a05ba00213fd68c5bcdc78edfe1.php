<?php $__env->startSection('title','Edit Payment'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                        <?php if(count($errors->all())): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="post" action="<?php echo e(route('payment.update',$row->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <table class="table">
                        <tr>
                            <td><label for="pay_id">Pay ID</label></td>
                            <td><input type=text name="pay_id" value="<?php echo e($row->pay_id); ?>" disabled></td>
                        </tr>
                        <tr>
                            <td><label for="status">Status</label></td>
                            <td>
                                    <input type=text name="status" value="<?php echo e($row->status); ?>">
                                    
                                </td>
                        </tr>
                        <tr>
                            <td><label for="amount">Amount</label></td>
                            <td><input type=text name="amount" value="<?php echo e($row->amount); ?>" ></td>
                        </tr>
                        <tr>
                            <td><label for="pay_date">Paid Date</label></td>
                            <td><input type=text name="pay_date" value="<?php echo e($row->pay_date); ?>" disabled></td>
                        </tr>

                        <tr>
                            <td colspan=2 align=center>
                            <button class="btn btn-success" type="submit">แก้ไขข้อมูล</button>
                            </td>
                        </tr>

                        </table>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/payment/editpayment.blade.php */ ?>