<?php $__env->startSection('title','Payment'); ?>

<style>
        th {
            font-size: 100%
        }
        td{
            font-size: 100%
        }
        .example_b {
color: #fff !important;
text-transform: uppercase;
background: #60a3bc;
padding: 20px;
border-radius: 50px;
display: inline-block;
border: none;
}

.example_b:hover {
text-shadow: 0px 0px 6px rgba(255, 255, 255, 1);
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.4s ease 0s;
}
    </style>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="warm-flame-gradient color-block mb-3 mx-auto rounded-circle z-depth-1-half"></div>
            <div class="panel panel-default">
                <div>
                    <p><div class="button_cont"><a class="example_b" href="<?php echo e(route('payment.create')); ?>" target="_blank" rel="nofollow noopener">เพิ่มข้อมูลการชำระเงิน</a></div></p>

                </div>

                <div class="panel-heading">
                <table class="table">
                    <thead>

                        <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Payment ID</th>
                        <th scope="col">Status</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Paid Date</th>
                        <th scope="col" colspan=2>Operation</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td><?php echo e($row->pay_id); ?></td>
                        <td><?php echo e($row->status); ?></td>
                        <td><?php echo e($row->amount); ?></td>
                        <td><?php echo e($row->pay_date); ?></td>
                        <td><a href="<?php echo e(route('payment.edit',$row->id)); ?>" class="btn btn-warning">edit</a></td>
                        <td><form action="<?php echo e(route('payment.destroy',$row->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button class="btn btn-danger" type=submit>Delete</button>
                            </form>
                        </tr>

                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/payment/indexpayment.blade.php */ ?>