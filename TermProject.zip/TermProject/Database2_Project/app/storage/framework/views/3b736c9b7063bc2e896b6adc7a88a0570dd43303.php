<?php $__env->startSection('title','Create Booking'); ?>

<style>

        td{
            font-size: 120%
        }
    </style>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="panel panel-default">

                <div class="panel-heading">
                        <?php if(count($errors->all())): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                <form method="post" action="<?php echo e(route('booking.store')); ?>">
                <?php echo e(csrf_field()); ?>

                <table class="table">
                    <tr>
                       <p> <td><label for="book_id">book_id</label></td> </p>
                        <td><input type=text name="book_id"></td>
                    </tr>
                    <tr>
                        <td><label for="checkIn_Time">checkIn_Time</label></td>
                        <td><input type=datetime-local name="checkIn_Time"></td>
                    </tr>
                    <tr>
                        <td><label for="checkOut_Time">checkOut_Time</label></td>
                        <td><input type=datetime-local name="checkOut_Time"></td>
                    </tr>
                    <tr>
                        <td><label for="cus_id">cus_id</label></td>
                        <td>
                            
                            <select name="cus_id">
                                    <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->cus_id); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="emp_id">emp_id</label></td>
                        <td>
                            
                            <select name="emp_id">
                                    <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->emp_id); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="room_no">room_no</label></td>
                        <td>
                            
                            <select name="room_no">
                                    <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->room_no); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="pay_id">pay_id</label></td>
                        <td>
                            
                            <select name="pay_id">
                                    <?php $__currentLoopData = $data4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->pay_id); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">เพิ่มข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/booking/createbooking.blade.php */ ?>