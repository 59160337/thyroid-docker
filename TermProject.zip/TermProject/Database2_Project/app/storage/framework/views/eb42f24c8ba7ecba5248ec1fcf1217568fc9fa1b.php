<style>

        th {
            font-size: 100%
        }
        td{
            font-size: 100%
        }
        .example_b {
color: #fff !important;
text-transform: uppercase;
background: #60a3bc;
padding: 20px;
border-radius: 50px;
display: inline-block;
border: none;
}

.example_b:hover {
text-shadow: 0px 0px 6px rgba(255, 255, 255, 1);
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.4s ease 0s;
}
    </style>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div>
                    <p><div class="button_cont"><a class="example_b" href="<?php echo e(route('room.create')); ?>" target="_blank" rel="nofollow noopener">เพิ่มข้อมูลห้อง</a></div></p>
                </div>

                <div class="panel-heading">
                <table class="table">
                    <thead>

                        <tr>
                        <th scope="col">No.</th>
                        <th scope="col">room NO</th>
                        <th scope="col">room capacity</th>
                        <th scope="col">room price</th>
                        <th scope="col">room description</th>
                        <th scope="col">bed type</th>
                        <th scope="col">type ID</th>
                        <th scope="col">Status ID</th>
                        <th scope="col" colspan=2>Operation</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td><?php echo e($row->room_no); ?></td>
                        <td><?php echo e($row->room_capacity); ?></td>
                        <td><?php echo e($row->room_price); ?></td>
                        <td><?php echo e($row->room_description); ?></td>
                        <td><?php echo e($row->bed_type); ?></td>
                        <td><?php echo e($row->type); ?></td>
                        <td><?php echo e($row->status); ?></td>
                        <td><a href="<?php echo e(route('room.edit', $row->id)); ?>" class="btn btn-warning">edit</a></td>
                        <td><form action="<?php echo e(route('room.destroy', $row->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button class="btn btn-danger" type=submit>Delete</button>
                            </form>
                        </tr>

                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/room/indexroom.blade.php */ ?>