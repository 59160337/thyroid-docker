<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Homepage</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/twitter-bootstrap/3.0.3/css/bootstrap-combined.min.css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #424242;
                background-image: url("bgdesert.jpg");
                color: #636b6f;
                font-family: 'Baskerville Old Face', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
                color: white;
            }

            .links > a {
                color: white;
                padding: 0 25px;
                font-size: 15px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>


            <br>
            <br>
            <br>
            <br>
            <br>
            <div class="content">
                <img align='center' src="images/logo.png" alt="" width="550" height="550">
                <div class="title m-b-md">
                    The Grand Chariott Hotel
                </div>
                <div class="title m-b-md">

                </div>
                <div class="links">
                    <a href="/customer">Customer</a>
                    <a href="/employee">Employee</a>
                    <a href="/payment">payment</a>
                    <a href="/room">Rooms</a>
                    <a href="/booking">Booking</a>

                </div>
            </div>
        </div>
    </body>
</html>



<?php /* /app/resources/views/welcome.blade.php */ ?>