<?php $__env->startSection('title','Employee'); ?>

<style>
        th {
            font-size: 100%
        }
        td{
            font-size: 100%
        }
        .example_b {
color: #fff !important;
text-transform: uppercase;
background: #60a3bc;
padding: 20px;
border-radius: 50px;
display: inline-block;
border: none;
}

.example_b:hover {
text-shadow: 0px 0px 6px rgba(255, 255, 255, 1);
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.4s ease 0s;
}
    </style>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="panel panel-default">
                <div><p>

                    <p><div class="button_cont"><a class="example_b" href="<?php echo e(route('employee.create')); ?>" target="_blank" rel="nofollow noopener">เพิ่มข้อมูลพนักงาน</a></div></p>
                </p>
                </div>

                <div class="panel-heading">
                <table class="table">
                    <thead>

                        <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Employee ID</th>
                        <th scope="col">Name</th>
                        <th scope="col" colspan=2>Operation</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td><?php echo e($row->emp_id); ?></td>
                        <td><?php echo e($row->emp_name); ?></td>
                        <td><a href="<?php echo e(route('employee.edit',$row->emp_id)); ?>" class="btn btn-warning">edit</a></td>
                        <td><form action="<?php echo e(route('employee.destroy',$row->emp_id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button class="btn btn-danger" type=submit>Delete</button>
                            </form>
                        </tr>

                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/employee/indexEmp.blade.php */ ?>