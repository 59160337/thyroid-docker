<?php $__env->startSection('title','Create Payment'); ?>

<style>

        td{
            font-size: 120%
        }
    </style>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">

                <div class="panel-heading">
                        <?php if(count($errors->all())): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                <form method="post" action="<?php echo e(route('payment.store')); ?>">
                <?php echo e(csrf_field()); ?>

                <table class="table">
                    <tr>
                        <td><label for="pay_id">Pay ID</label></td>
                        <td><input type=text name="pay_id"></td>
                    </tr>
                    <tr>
                        
                        <td><label for="status">Status</label></td>
                        <td>
                            
                            <select name="status">
                                <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="amount">Amount</label></td>
                        <td><input type=text name="amount"></td>
                    </tr>
                    <tr>
                        <td><label for="pay_date">Paid Date</label></td>
                        <td><input type=date name="pay_date"></td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">เพิ่มข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/payment/createpayment.blade.php */ ?>