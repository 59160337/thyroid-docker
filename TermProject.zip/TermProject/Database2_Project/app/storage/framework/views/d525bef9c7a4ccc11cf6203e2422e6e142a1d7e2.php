<?php $__env->startSection('title','Edit Booking'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                        <?php if(count($errors->all())): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="post" action="<?php echo e(route('booking.update',$row->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field("PUT"); ?>
                <table class="table">
                    <tr>
                        <td><label for="book_id">book_id</label></td>
                        <td><input type=text name="book_id" value="<?php echo e($row->book_id); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="checkIn_Time">checkIn_Time</label></td>
                        <td><input type=date name="checkIn_Time" value="<?php echo e($row->checkIn_Time); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="checkOut_Time">checkOut_Time</label></td>
                        <td><input type=date name="checkOut_Time" value="<?php echo e($row->checkOut_Time); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="cus_id">cus_id</label></td>
                        
                        <td>
                            <select name="cus_id" id="cus_id">
                            <option value="<?php echo e($data2['id']); ?>"><?php echo e($data2['cus_id']); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="emp_id">emp_id</label></td>
                        <td><input type=text name="emp_id" value="<?php echo e($data4->emp_id); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="room_no">room_no</label></td>
                        <td><input type=text name="room_no" value="<?php echo e($data5->room_no); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="pay_id">pay_id</label></td>
                        <td><input type=text name="pay_id" value="<?php echo e($data3->pay_id); ?>"></td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">แก้ไขข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/booking/editbooking.blade.php */ ?>