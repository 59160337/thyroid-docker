<style>

        td{
            font-size: 120%
        }
    </style>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                        <?php if(count($errors->all())): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="post" action="<?php echo e(route('room.update',$row->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field("PUT"); ?>
                <table class="table">
                    <tr>
                        <td><label for="room_no">room_no</label></td>
                        <td><input type=text name="room_no" value="<?php echo e($row->room_no); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="room_capacity">room_capacity</label></td>
                        <td><input type=text name="room_capacity" value="<?php echo e($row->room_capacity); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="room_price">room_price</label></td>
                        <td><input type=text name="room_price" value="<?php echo e($row->room_price); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="room_description">room_description</label></td>
                        <td><input type=text name="room_description" value="<?php echo e($row->room_description); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="bed_type">bed_type</label></td>
                        <td><input type=text name="bed_type" value="<?php echo e($row->bed_type); ?>"></td>
                    </tr>
                    <tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <td><label for="type_id">type_id</label></td>
                        <td>
                            <select id="room_type" name="type_id">
                                
                                <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row2->id); ?>"><?php echo e($row2->type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="status_id">status_id</label></td>
                        <td>
                            <select id="room_status" name="status_id">
                                
                                <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row3->id); ?>"><?php echo e($row3->status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">แก้ไขข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/room/editroom.blade.php */ ?>