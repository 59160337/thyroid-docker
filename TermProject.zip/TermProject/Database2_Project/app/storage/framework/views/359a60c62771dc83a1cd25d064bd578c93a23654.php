<?php $__env->startSection('title','Customer'); ?>

<style>
    th {
        font-size: 100%
    }
    td{
        font-size: 100%
    }
    .example_b {
color: #fff !important;
text-transform: uppercase;
background: #60a3bc;
padding: 20px;
border-radius: 50px;
display: inline-block;
border: none;
}

.example_b:hover {
text-shadow: 0px 0px 6px rgba(255, 255, 255, 1);
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.4s ease 0s;
}

</style>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <!-- Grid column -->
        <div class="col-md-14">
            <div class="panel panel-default">
                <div>

                    <p><div class="button_cont"><a class="example_b" href="<?php echo e(route('customer.create')); ?>" target="_blank" rel="nofollow noopener">เพิ่มข้อมูลลูกค้า</a></div></p>

                </div>

                <div class="panel-heading">
                <table class="table">
                    <thead>

                        <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Customer ID</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Address</th>
                        <th scope="col">Phone No.</th>
                        <th scope="col">Amount of Guest</th>
                        <th scope="col" colspan=2>Operation</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td><?php echo e($row->cus_id); ?></td>
                        <td><?php echo e($row->first_name); ?></td>
                        <td><?php echo e($row->last_name); ?></td>
                        <td><?php echo e($row->email); ?></td>
                        <td><?php echo e($row->address); ?></td>
                        <td><?php echo e($row->phone_no); ?></td>
                        <td><?php echo e($row->num_of_guest); ?></td>
                        <td><a href="<?php echo e(route('customer.edit',$row->cus_id)); ?>" class="btn btn-warning">edit</a></td>
                        <td><form action="<?php echo e(route('customer.destroy',$row->cus_id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button class="btn btn-danger" type=submit>Delete</button>
                            </form>
                        </tr>

                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/customer/indexcustomer.blade.php */ ?>