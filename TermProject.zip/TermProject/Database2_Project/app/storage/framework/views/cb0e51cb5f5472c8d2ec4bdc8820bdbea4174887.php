<?php $__env->startSection('title','Edit Customer'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                        <?php if(count($errors->all())): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                <form method="post" action="<?php echo e(route('customer.update',$customer->cus_id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field("PUT"); ?>
                <table class="table">
                    <tr>
                        <td><label for="cus_id">Customer_id</label></td>
                        <td><input type=text name="cus_id" value="<?php echo e($customer->cus_id); ?>" disabled></td>
                    </tr>
                    <tr>
                        <td><label for="first_name">First Name</label></td>
                        <td><input type=text name="first_name" value="<?php echo e($customer->first_name); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="last_name">Last Name</label></td>
                        <td><input type=text name="last_name" value="<?php echo e($customer->last_name); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="email">Email</label></td>
                        <td><input type=text name="email" value="<?php echo e($customer->email); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="address">Address</label></td>
                        <td><input type=text name="address" value="<?php echo e($customer->address); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="phone_no">Phone No.</label></td>
                        <td><input type=text name="phone_no" value="<?php echo e($customer->phone_no); ?>"></td>
                    </tr>
                    <tr>
                        <td><label for="num_of_guest">Amount of Guest</label></td>
                        <td><input type=text name="num_of_guest" value="<?php echo e($customer->num_of_guest); ?>"></td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">แก้ไขข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/customer/editcustomer.blade.php */ ?>