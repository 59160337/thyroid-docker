<?php $__env->startSection('title','Create Customer'); ?>

<style>

        td{
            font-size: 120%
        }
 </style>

<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php if(count($errors->all())): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                <form method="POST" action="<?php echo e(route('customer.store')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <table class="table">
                        <tr>
                            <td><label for="cus_id">หมายเลขลูกค้า</label></td>
                            <td><input type="text" name="cus_id"> </td>
                        </tr>
                        <tr><td><label for="first_name">ชื่อ</label></td>
                            <td><input type="text" name="first_name"> </td>
                        </tr>
                        <tr>
                            <td><label for="last_name">นามสกุล</label></td>
                            <td><input type="text" name="last_name"> </td>
                        </tr>
                        <tr>
                            <td><label for="email">E-mail</label></td>
                            <td><input type="text" name="email"> </td>
                        </tr>
                        <tr>
                            <td><label for="address">ที่อยู่</label></td>
                            <td><input type="text" name="address"> </td>
                        </tr>
                        <tr>
                            <td><label for="phone_no">หมายเลขโทรศัพท์</label></td>
                            <td><input type="text" name="phone_no"> </td>
                        </tr>
                        <tr>
                            <td><label for="num_of_guest">จำนวนผู้เข้าพัก</label></td>
                            <td><input type="number" name="num_of_guest"> </td>
                        </tr>
                        <td colspan="2" align="center">
                                <button class="btn btn-success" type="submit">เพิ่มข้อมูล</button>

                            </td>
                    </table>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/customer/createcustomer.blade.php */ ?>