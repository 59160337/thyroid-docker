<style>

        td{
            font-size: 120%
        }
    </style>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="panel panel-default">

                <div class="panel-heading">
                        <?php if(count($errors->all())): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                <form method="post" action="<?php echo e(route('room.store')); ?>">
                <?php echo e(csrf_field()); ?>

                <table class="table">
                    <tr>
                        <td><label for="room_no">Room No</label></td>
                        <td><input type=text name="room_no"></td>
                    </tr>
                    <tr>
                        <td><label for="room_capacity">room_capacity</label></td>
                        <td><input type=text name="room_capacity"></td>
                    </tr>
                    <tr>
                        <td><label for="room_price">room_price</label></td>
                        <td><input type=text name="room_price"></td>
                    </tr>
                    <tr>
                        <td><label for="room_description">room_description</label></td>
                        <td><input type=text name="room_description"></td>
                    </tr>
                    <tr>
                        <td><label for="bed_type">bed_type</label></td>
                        <td><input type=text name="bed_type"></td>
                    </tr>
                    <tr>
                        <td><label for="type_id">type_id</label></td>
                        <td>
                            
                            <select name="type_id">
                                <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                            <td><label for="status_id">status_id</label></td>
                            <td>
                                
                                <select name="status_id">
                                    <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->status); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </td>
                        </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">เพิ่มข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/room/createroom.blade.php */ ?>