<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/customer', 'CustomerController@index');

Route::get('/employee', 'EmployeeController@index');

Route::get('/payment', 'PaymentController@index');

Route::get('/booking', 'BookingController@index');
//Route::post('booking', 'BookingController@update')->name('booking.update');

Route::get('/room', 'RoomController@index');
//Route::post('room', 'RoomController@update')->name('room.update');

Route::get('/admin', 'AdminController@login');

Route::match(['get', 'post'], '/admin','AdminController@login');

// Route::get('/admin', 'AdminController@index');

Route::resource('customer', 'CustomerController');

Route::resource('employee', 'EmployeeController');

Route::resource('payment', 'PaymentController');

Route::resource('booking', 'BookingController');

Route::resource('room', 'RoomController');

// Route::resource('admin', 'AdminController');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//Route for normal user
Route::group(['middleware' => ['auth']], function () {
    Route::get('/home', 'HomeController@index');
});

//Route for admin
Route::group(['prefix' => 'admin'], function(){
    Route::group(['middleware' => ['admin']], function(){
        Route::get('/dashboard', 'admin\AdminController@index');
    });
});
