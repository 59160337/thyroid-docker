@extends('layouts.app')

@section('title','Booking')

@section('content')
<style>

        th {
            font-size: 100%
        }
        td{
            font-size: 100%
        }
        .example_b {
color: #fff !important;
text-transform: uppercase;
background: #60a3bc;
padding: 20px;
border-radius: 50px;
display: inline-block;
border: none;
}

.example_b:hover {
text-shadow: 0px 0px 6px rgba(255, 255, 255, 1);
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.4s ease 0s;
}
    </style>
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div>
                        <p><div class="button_cont"><a class="example_b" href="{{ route('booking.create') }}" target="_blank" rel="nofollow noopener">เพิ่มข้อมูลการจอง</a></div></p>
                </div>

                <div class="panel-heading">
                <table class="table">
                    <thead>

                        <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Book ID</th>
                        <th scope="col">checkIn_Time</th>
                        <th scope="col">checkOut_Time</th>
                        <th scope="col">customer ID</th>
                        <th scope="col">employee ID</th>
                        <th scope="col">room ID</th>
                        <th scope="col">pay ID</th>
                        <th scope="col" colspan=2>Operation</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    @foreach($data as $row)
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td>{{ $row->book_id}}</td>
                        <td>{{ $row->checkIn_Time}}</td>
                        <td>{{ $row->checkOut_Time}}</td>
                        <td>{{ $row->Name}}</td>
                        <td>{{ $row->emp_name}}</td>
                        <td>{{ $row->room_no}}</td>
                        <td>{{ $row->status}}</td>
                        {{-- <td><a href="{{ route('booking.edit',$row->id) }}" class="btn btn-warning">edit</a></td> --}}
                        <td><form action="{{ route('booking.destroy',$row->id) }}" method="post">
                            @csrf
                            @method("DELETE")
                            <button class="btn btn-danger" type=submit>Delete</button>
                            </form>
                        </tr>

                    </tbody>
                    @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
