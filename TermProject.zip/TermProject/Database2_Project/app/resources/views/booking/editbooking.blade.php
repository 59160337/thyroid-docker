@extends('layouts.app')

@section('title','Edit Booking')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                        @if(count($errors->all()))
                        <div class="alert alert-danger">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
                @foreach ($booking as $row)
                <form method="post" action="{{ route('booking.update',$row->id) }}">
                @csrf
                @method("PUT")
                <table class="table">
                    <tr>
                        <td><label for="book_id">book_id</label></td>
                        <td><input type=text name="book_id" value="{{ $row->book_id }}"></td>
                    </tr>
                    <tr>
                        <td><label for="checkIn_Time">checkIn_Time</label></td>
                        <td><input type=date name="checkIn_Time" value="{{ $row->checkIn_Time }}"></td>
                    </tr>
                    <tr>
                        <td><label for="checkOut_Time">checkOut_Time</label></td>
                        <td><input type=date name="checkOut_Time" value="{{ $row->checkOut_Time }}"></td>
                    </tr>
                    <tr>
                        <td><label for="cus_id">cus_id</label></td>
                        {{-- <td><input type=text name="cus_id" value="{{ $booking->cus_id }}"></td> --}}
                        <td>
                            <select name="cus_id" id="cus_id">
                            <option value="{{ $data2['id'] }}">{{ $data2['cus_id'] }}</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="emp_id">emp_id</label></td>
                        <td><input type=text name="emp_id" value="{{ $data4->emp_id }}"></td>
                    </tr>
                    <tr>
                        <td><label for="room_no">room_no</label></td>
                        <td><input type=text name="room_no" value="{{ $data5->room_no }}"></td>
                    </tr>
                    <tr>
                        <td><label for="pay_id">pay_id</label></td>
                        <td><input type=text name="pay_id" value="{{ $data3->pay_id }}"></td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">แก้ไขข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    @endforeach
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
