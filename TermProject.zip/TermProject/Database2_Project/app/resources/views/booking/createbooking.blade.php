@extends('layouts.app')

@section('title','Create Booking')

<style>

        td{
            font-size: 120%
        }
    </style>

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="panel panel-default">

                <div class="panel-heading">
                        @if(count($errors->all()))
                        <div class="alert alert-danger">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
                <form method="post" action="{{ route('booking.store') }}">
                {{ csrf_field() }}
                <table class="table">
                    <tr>
                       <p> <td><label for="book_id">book_id</label></td> </p>
                        <td><input type=text name="book_id"></td>
                    </tr>
                    <tr>
                        <td><label for="checkIn_Time">checkIn_Time</label></td>
                        <td><input type=datetime-local name="checkIn_Time"></td>
                    </tr>
                    <tr>
                        <td><label for="checkOut_Time">checkOut_Time</label></td>
                        <td><input type=datetime-local name="checkOut_Time"></td>
                    </tr>
                    <tr>
                        <td><label for="cus_id">cus_id</label></td>
                        <td>
                            {{-- <input type=text name="cus_id"> --}}
                            <select name="cus_id">
                                    @foreach($data1 as $row)
                                <option value="{{$row->id}}">{{$row->cus_id}}</option>
                                    @endforeach

                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="emp_id">emp_id</label></td>
                        <td>
                            {{-- <input type=text name="emp_id"> --}}
                            <select name="emp_id">
                                    @foreach($data2 as $row)
                                <option value="{{$row->id}}">{{$row->emp_id}}</option>
                                    @endforeach

                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="room_no">room_no</label></td>
                        <td>
                            {{-- <input type=text name="room_id"> --}}
                            <select name="room_no">
                                    @foreach($data3 as $row)
                                <option value="{{$row->id}}">{{$row->room_no}}</option>
                                    @endforeach

                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="pay_id">pay_id</label></td>
                        <td>
                            {{-- <input type=text name="pay_id"> --}}
                            <select name="pay_id">
                                    @foreach($data4 as $row)
                                <option value="{{$row->id}}">{{$row->pay_id}}</option>
                                    @endforeach

                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">เพิ่มข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
