@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div>
                    <a href="{{ route('customer.create') }}" class="btn btn-success">เพิ่มข้อมูลการจอง</a>
                </div>

                <div class="panel-heading">
                <table class="table">
                    <thead>

                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Customer cus_id</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Address</th>
                        <th scope="col">Phone No.</th>
                        <th scope="col">Amount of Guest</th>
                        <th scope="col" colspan=2>Operation</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    @foreach($customer as $row)
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td>{{ $row->cus_id }}</td>
                        <td>{{ $row->first_name }}</td>
                        <td>{{ $row->last_name }}</td>
                        <td>{{ $row->email }}</td>
                        <td>{{ $row->address }}</td>
                        <td>{{ $row->phone_no }}</td>
                        <td>{{ $row->num_of_guest }}</td>
                        <td><a href="{{ route('customer.edit',$row->cus_id) }}" class="btn btn-warning">edit</a></td>
                        <td><form action="{{ route('customer.destroy',$row->cus_id) }}" method="post">
                            @csrf
                            @method("DELETE")
                            <button class="btn btn-danger" type=submit>Delete</button>
                            </form>
                        </tr>

                    </tbody>
                    @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
