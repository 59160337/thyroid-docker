@extends('layouts.app')

<style>

        td{
            font-size: 120%
        }
    </style>


@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                        @if(count($errors->all()))
                        <div class="alert alert-danger">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
                @foreach ($data as $row)
                <form method="post" action="{{ route('room.update',$row->id) }}">
                @csrf
                @method("PUT")
                <table class="table">
                    <tr>
                        <td><label for="room_no">room_no</label></td>
                        <td><input type=text name="room_no" value="{{ $row->room_no }}"></td>
                    </tr>
                    <tr>
                        <td><label for="room_capacity">room_capacity</label></td>
                        <td><input type=text name="room_capacity" value="{{ $row->room_capacity }}"></td>
                    </tr>
                    <tr>
                        <td><label for="room_price">room_price</label></td>
                        <td><input type=text name="room_price" value="{{ $row->room_price }}"></td>
                    </tr>
                    <tr>
                        <td><label for="room_description">room_description</label></td>
                        <td><input type=text name="room_description" value="{{ $row->room_description }}"></td>
                    </tr>
                    <tr>
                        <td><label for="bed_type">bed_type</label></td>
                        <td><input type=text name="bed_type" value="{{ $row->bed_type }}"></td>
                    </tr>
                    <tr>
                    @endforeach

                        <td><label for="type_id">type_id</label></td>
                        <td>
                            <select id="room_type" name="type_id">
                                {{-- <option value="{{ $data2['id'] }}">{{ $data2['type'] }}</option> --}}
                                @foreach($data2 as $row2)
                                    <option value="{{$row2->id}}">{{$row2->type}}</option>
                                @endforeach
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="status_id">status_id</label></td>
                        <td>
                            <select id="room_status" name="status_id">
                                {{-- <option value="{{ $data3['id'] }}">{{ $data3['status'] }}</option> --}}
                                @foreach($data3 as $row3)
                                    <option value="{{$row3->id}}">{{$row3->status}}</option>
                                @endforeach
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">แก้ไขข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
