@extends('layouts.app')

@section('title','Create Payment')

<style>

        td{
            font-size: 120%
        }
    </style>

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">

                <div class="panel-heading">
                        @if(count($errors->all()))
                        <div class="alert alert-danger">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
                <form method="post" action="{{ route('payment.store') }}">
                {{ csrf_field() }}
                <table class="table">
                    <tr>
                        <td><label for="pay_id">Pay ID</label></td>
                        <td><input type=text name="pay_id"></td>
                    </tr>
                    <tr>
                        {{-- <td><label for="status">Status</label></td>
                        <td><input type=text name="status"></td> --}}
                        <td><label for="status">Status</label></td>
                        <td>
                            {{-- <input type=text name="type_id"> --}}
                            <select name="status">
                                @foreach($payment as $row)
                            <option value="{{$row->id}}">{{$row->status}}</option>
                                @endforeach
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="amount">Amount</label></td>
                        <td><input type=text name="amount"></td>
                    </tr>
                    <tr>
                        <td><label for="pay_date">Paid Date</label></td>
                        <td><input type=date name="pay_date"></td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">เพิ่มข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
