@extends('layouts.app')

@section('title','Edit Payment')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                        @if(count($errors->all()))
                        <div class="alert alert-danger">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
                    @foreach ($payment as $row)
                    <form method="post" action="{{ route('payment.update',$row->id) }}">
                    @csrf
                    @method('PUT')
                    <table class="table">
                        <tr>
                            <td><label for="pay_id">Pay ID</label></td>
                            <td><input type=text name="pay_id" value="{{ $row->pay_id }}" disabled></td>
                        </tr>
                        <tr>
                            <td><label for="status">Status</label></td>
                            <td>
                                    <input type=text name="status" value="{{ $row->status }}">
                                    {{-- <select name="status">
                                        @foreach ($paystatus as $row2)
                                        <option value="{{$row2->id}}">{{$row2->status}}</option>
                                        @endforeach
                                    </select> --}}
                                </td>
                        </tr>
                        <tr>
                            <td><label for="amount">Amount</label></td>
                            <td><input type=text name="amount" value="{{ $row->amount }}" ></td>
                        </tr>
                        <tr>
                            <td><label for="pay_date">Paid Date</label></td>
                            <td><input type=text name="pay_date" value="{{ $row->pay_date }}" disabled></td>
                        </tr>

                        <tr>
                            <td colspan=2 align=center>
                            <button class="btn btn-success" type="submit">แก้ไขข้อมูล</button>
                            </td>
                        </tr>

                        </table>
                        </form>
                        @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
