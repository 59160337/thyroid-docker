@extends('layouts.app')

@section('title','Employee')

<style>
        th {
            font-size: 100%
        }
        td{
            font-size: 100%
        }
        .example_b {
color: #fff !important;
text-transform: uppercase;
background: #60a3bc;
padding: 20px;
border-radius: 50px;
display: inline-block;
border: none;
}

.example_b:hover {
text-shadow: 0px 0px 6px rgba(255, 255, 255, 1);
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.4s ease 0s;
}
    </style>

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="panel panel-default">
                <div><p>

                    <p><div class="button_cont"><a class="example_b" href="{{ route('employee.create') }}" target="_blank" rel="nofollow noopener">เพิ่มข้อมูลพนักงาน</a></div></p>
                </p>
                </div>

                <div class="panel-heading">
                <table class="table">
                    <thead>

                        <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Employee ID</th>
                        <th scope="col">Name</th>
                        <th scope="col" colspan=2>Operation</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    @foreach($employee as $row)
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td>{{ $row->emp_id}}</td>
                        <td>{{ $row->emp_name}}</td>
                        <td><a href="{{ route('employee.edit',$row->emp_id) }}" class="btn btn-warning">edit</a></td>
                        <td><form action="{{ route('employee.destroy',$row->emp_id) }}" method="post">
                            @csrf
                            @method("DELETE")
                            <button class="btn btn-danger" type=submit>Delete</button>
                            </form>
                        </tr>

                    </tbody>
                    @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
