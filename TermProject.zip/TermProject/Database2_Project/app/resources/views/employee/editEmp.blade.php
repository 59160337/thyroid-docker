@extends('layouts.app')

@section('title','Edit Employee')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                        @if(count($errors->all()))
                        <div class="alert alert-danger">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
                <form method="post" action="{{ route('employee.update',$employee->emp_id) }}">
                @csrf
                @method("PUT")
                <table class="table">
                    <tr>
                        <td><label for="emp_id">Employee ID</label></td>
                        <td><input type=text name="emp_id" value="{{ $employee->emp_id }}" disabled></td>
                    </tr>
                    <tr>
                        <td><label for="emp_name">Name</label></td>
                        <td><input type=text name="emp_name" value="{{ $employee->emp_name }}"></td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">แก้ไขข้อมูล</button>
                        </td>
                    </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
