@extends('layouts.app')

@section('title','Customer')

<style>
    th {
        font-size: 100%
    }
    td{
        font-size: 100%
    }
    .example_b {
color: #fff !important;
text-transform: uppercase;
background: #60a3bc;
padding: 20px;
border-radius: 50px;
display: inline-block;
border: none;
}

.example_b:hover {
text-shadow: 0px 0px 6px rgba(255, 255, 255, 1);
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.4s ease 0s;
}

</style>

@section('content')

<div class="container">
    <div class="row">
        <!-- Grid column -->
        <div class="col-md-14">
            <div class="panel panel-default">
                <div>

                    <p><div class="button_cont"><a class="example_b" href="{{ route('customer.create') }}" target="_blank" rel="nofollow noopener">เพิ่มข้อมูลลูกค้า</a></div></p>

                </div>

                <div class="panel-heading">
                <table class="table">
                    <thead>

                        <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Customer ID</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Address</th>
                        <th scope="col">Phone No.</th>
                        <th scope="col">Amount of Guest</th>
                        <th scope="col" colspan=2>Operation</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    @foreach($customer as $row)
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td>{{ $row->cus_id }}</td>
                        <td>{{ $row->first_name }}</td>
                        <td>{{ $row->last_name }}</td>
                        <td>{{ $row->email }}</td>
                        <td>{{ $row->address }}</td>
                        <td>{{ $row->phone_no }}</td>
                        <td>{{ $row->num_of_guest }}</td>
                        <td><a href="{{ route('customer.edit',$row->cus_id) }}" class="btn btn-warning">edit</a></td>
                        <td><form action="{{ route('customer.destroy',$row->cus_id) }}" method="post">
                            @csrf
                            @method("DELETE")
                            <button class="btn btn-danger" type=submit>Delete</button>
                            </form>
                        </tr>

                    </tbody>
                    @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
