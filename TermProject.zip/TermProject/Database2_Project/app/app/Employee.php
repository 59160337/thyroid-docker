<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $table = "Employee";

    protected $primaryKey = 'emp_id';

    public $incrementing = false;

    public $timestamps = false;

    protected $fillable = [
        'emp_id','emp_name'
    ];
}
