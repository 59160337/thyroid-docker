<?php

namespace App\Http\Controllers;

use DB;

use Illuminate\Http\Request;

use App\Room;

class RoomController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $room = Room::all();
        $data = DB::table('Room')
            ->JOIN('Room_type', 'Room_type.id', '=' , 'Room.type_id')
            ->JOIN('Room_status', 'Room_status.id', '=', 'Room.status_id')
            ->SELECT('Room.*','Room_type.type','Room_status.status' )
            ->get();

            #return $data;
            return view('room.indexroom',compact('data'));

        #'Room.id','Room.room_no','Room.room_capacity','Room.room_price','Room.room_description','Room.bed_type'
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = DB::table('Room')->select('Room.*')->get();
        $data2 = DB::table('Room_type')->select('Room_type.*')->get();
        $data3 = DB::table('Room_status')->select('Room_status.*')->get();
        return view('room.createroom', compact('data','data2','data3'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = new Room;

        $request->validate(
            [
                'room_no' => 'required|unique:Room,room_no',
                'room_capacity' => 'required',
                'room_price' => 'required',
                'room_description' => 'required',
                'bed_type' => 'required',
                'type_id' => 'required',
                'status_id' => 'required'
            ]
        );

        $data->room_no = $request->room_no;
        $data->room_capacity = $request->room_capacity;
        $data->room_price = $request->room_price;
        $data->room_description = $request->room_description;
        $data->bed_type = $request->bed_type;
        $data->type_id = $request->type_id;
        $data->status_id = $request->status_id;
        $data->save();

        return redirect('room');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $keepid = $id;
        // $data = Room::find($id);
        $data = DB::select('select * from Room where id=?',[$keepid]);
        $data2 = DB::table('Room_type')->select('Room_type.*')->get();
        $data3 = DB::table('Room_status')->select('Room_status.*')->get();
        return view('room.editroom',compact('data','data2','data3'));
        // return $data;

        // return $data , $data2 , $data3;
        // return $data2;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // $data = Room::find($id);
        $request->validate(
            [
                'room_no' => 'required',
                'room_capacity' => 'required',
                'room_price' => 'required',
                'room_description' => 'required',
                'bed_type' => 'required',
                'type_id' => 'required',
                'status_id' => 'required'
            ]
        );

        // $room = DB::select('SELECT * FROM Room WHERE room_no = ?', [$request->room_no]);
        $room_no = $request->room_no;
        $room_capacity = $request->room_capacity;
        $room_price = $request->room_price;
        $room_description = $request->room_description;
        $bed_type = $request->bed_type;
        $type_id = $request->type_id;
        $status_id = $request->status_id;

        $roomupdate = DB::update('update Room set room_capacity = ?, room_price = ?,
                                  room_description = ?, bed_type = ?, type_id = ?, status_id = ?
                                  where id = ?',
                                  [$room_capacity,$room_price,$room_description,$bed_type,
                                  $type_id,$status_id,$id]);
        return redirect('room');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $data = Room::where('id',$id)->first();
        $data->delete();
        return redirect('/room');
    }
}
