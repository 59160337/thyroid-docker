<?php

namespace App\Http\Controllers;

use DB;

use Illuminate\Http\Request;

use App\Booking;

class BookingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $booking = Booking::all();
        $data = DB::table('Booking')
            ->JOIN('Customer', 'Customer.id', '=' , 'Booking.cus_id')
            ->JOIN('Employee', 'Employee.id', '=', 'Booking.emp_id')
            ->JOIN('Room', 'Room.id', '=', 'Booking.room_no')
            ->JOIN('Payment', 'Payment.id', '=', 'Booking.pay_id')
            ->SELECT('Booking.*',DB::raw('CONCAT(Customer.first_name, " ",Customer.last_name) as Name'),'Employee.emp_name','Room.room_no','Payment.status' )
            ->get();

        return view('booking.indexbooking',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data1 = DB::table('Customer')->select('Customer.*')->get();
        $data2 = DB::table('Employee')->select('Employee.*')->get();
        $data3 = DB::table('Room')->select('Room.*')->get();
        $data4 = DB::table('Payment')->select('Payment.*')->get();

        return view('booking.createbooking', compact('data1','data2','data3','data4'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $booking = new Booking;

        $request->validate(
            [
                'book_id' => 'required|unique:Booking,book_id',
                'checkIn_Time' => 'required',
                'checkOut_Time' => 'required',
                'cus_id' => 'required',
                'emp_id' => 'required',
                'room_no' => 'required',
                'pay_id' => 'required'
            ]
        );

        $booking->book_id = $request->book_id;
        $booking->checkIn_Time = $request->checkIn_Time;
        $booking->checkOut_Time = $request->checkOut_Time;
        $booking->cus_id = $request->cus_id;
        $booking->emp_id = $request->emp_id;
        $booking->room_no = $request->room_no;
        $booking->pay_id = $request->pay_id;
        $booking->save();

        return redirect('booking');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // $booking = Booking::find($id);
        $booking = DB::select('select * from Booking where id = ?', [$id]);
        $data1 = DB::table('Customer')->select('Customer.*')->get();
        $data2 = DB::table('Payment')->select('Payment.*')->get();
        $data3 = DB::table('Employee')->select('Employee.*')->get();
        $data4 = DB::table('Room')->where('Room.*')->get();
        return view('booking.editbooking',compact('data','data2','data3','data4','data5'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate(
            [
                'book_id' => 'required',
                'checkIn_Time' => 'required',
                'checkOut_Time' => 'required',
                'cus_id' => 'required',
                'emp_id' => 'required',
                'room_no' => 'required',
                'pay_id' => 'required'
            ]
        );

        $booking = Booking::find($id);
        $booking->book_id = $request->book_id;
        $booking->checkIn_Time = $request->checkIn_Time;
        $booking->checkOut_Time = $request->checkOut_Time;
        $booking->cus_id = $request->cus_id;
        $booking->emp_id = $request->emp_id;
        $booking->room_no = $request->room_no;
        $booking->pay_id = $request->pay_id;
        $booking->save();

        return redirect('/booking');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $booking = Booking::find($id);
        $booking->delete();

        return redirect('/booking');
    }
}
