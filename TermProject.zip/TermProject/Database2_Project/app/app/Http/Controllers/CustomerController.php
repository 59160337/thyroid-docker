<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Customer;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customer = Customer::all();
        return view('customer.indexcustomer',compact('customer'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('customer.createcustomer');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $customer = new Customer;

        $request->validate(
            [
                'cus_id' => 'required|unique:Customer,cus_id|max:10',
                'first_name' => 'required|max:45',
                'last_name' => 'required|max:45',
                'email' => 'required|email',
                'phone_no' => 'required|max:10',
                'num_of_guest' => 'required'
            ]
        );

        $customer->cus_id = $request->cus_id;
        $customer->first_name = $request->first_name;
        $customer->last_name = $request->last_name;
        $customer->email = $request->email;
        $customer->address = $request->address;
        $customer->phone_no = $request->phone_no;
        $customer->num_of_guest = $request->num_of_guest;
        $customer->save();

        return redirect('customer');
        $request->session()->flash('message', 'บันทึกข้อมูลเรียบร้อย');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $customer = Customer::find($id);
        return view('customer.editcustomer',compact('customer'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            //'cus_id' => 'required',
            'first_name' => 'required|max:45',
            'last_name' => 'required|max:45',
            'email' => 'required|email',
            'phone_no' => 'required|max:10',
            'num_of_guest' => 'required'
        ]);

        $customer = Customer::find($id);
        //$customer->cus_id = $request->cus_id;
        $customer->first_name = $request->first_name;
        $customer->last_name = $request->last_name;
        $customer->email = $request->email;
        $customer->address = $request->address;
        $customer->phone_no = $request->phone_no;
        $customer->num_of_guest = $request->num_of_guest;

        $customer->save();

        $request->session()->flash('message', 'แก้ไขข้อมูลสำเร็จ');

        return redirect('/customer');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $customer = Customer::find($id);
        $customer->delete();

        return redirect('/customer')->with('success', 'Contact deleted!');
    }
}
