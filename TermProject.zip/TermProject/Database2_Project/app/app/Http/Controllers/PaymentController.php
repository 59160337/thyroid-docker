<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Payment;

use DB;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $payment = Payment::all();
        return view('payment.indexpayment',compact('payment'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $payment = DB::select('select * from Payment');
        return view('payment.createpayment',compact('payment'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $payment = new Payment;

        $request->validate(
            [
            'pay_id' => 'required|unique:Payment,pay_id',
            'status' => 'required',
            'amount' => 'required',
            'pay_date' => 'required'
            ]
        );

        $payment->pay_id = $request->pay_id;
        $payment->status = $request->status;
        $payment->amount = $request->amount;
        $payment->pay_date = $request->pay_date;
        $payment->save();
        return redirect('payment');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $payment = DB::select('select * from Payment where id = ?', [$id]);
        // $paystatus = DB::select('select * from Payment');
        return view('payment.editpayment',compact('payment' , 'id','paystatus'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate(
            [
            //'pay_id' => 'required',
            'status' => 'required',
            'amount' => 'required',
            //'pay_date' => 'required'
            ]
        );

        //$payment = Payment::find($id);
        $status = $request->status;
        $amount = $request->amount;
        $payment = DB::update('update Payment set status = ?,amount = ? where id = ? ', [$status,$amount,$id]);
        // return $payment;
        // return $request->pay_date;

        // Payment::where('pay_id', $id)->update( array('pay_id'=>$request->get('pay_id'),
        //                                                 'status'=>$request->get('status'),
        //                                                 'amount'=>$request->get('amount'),
        //                                                 'pay_date'=>$request->get('pay_date') ));
        return redirect('payment');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = Payment::where('id',$id)->first();
        $post->delete();
        return redirect('payment');
    }
}
