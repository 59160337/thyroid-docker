<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $table = "Customer";

    protected $primaryKey = 'cus_id';

    public $incrementing = false;

    protected $fillable = [
        'cus_id','first_name','last_name','email','address','phone_no','num_of_guest'
    ];
}
