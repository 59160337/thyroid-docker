<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $table = "Booking";

    protected $fillable = [
        'book_id','checkIn_Time','checkOut_Time','cus_id','emp_id','room_no','pay_id'
    ];

    public function customer() {
        return $this->belongsTo(Customer::class);
    }

    public function employee() {
        return $this->belongsTo(Employee::class);
    }

    public function room() {
        return $this->belongsTo(Room::class);
    }

    public function payment() {
        return $this->belongsTo(Payment::class);
    }

    // protected function create(array $request){
    //     $payment = Payment::create([
    //         'pay_id',
    //         'status',
    //         'amount'
    //     ]);
    // }

    protected function getTotalPrice() {

    }
}
