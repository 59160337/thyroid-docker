<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Room extends Model
{
    protected $table = "Room";

    protected $primaryKey = 'room_no';

    protected $fillable = [
        'id','room_no','room_capacity','room_price','room_description','bed_type','type_id','status_id'
    ];

}
